<?php 

$conn= new mysqli("localhost","1205427","nnbtrung211001","1205427db2");
// $conn= new mysqli("localhost","root","","pos_banhang");

if (!$conn) {
    echo "Connect Database Fail!!!";
}
?>